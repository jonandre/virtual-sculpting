#pragma once
// interface class
class Model
{
public:
private:
};

